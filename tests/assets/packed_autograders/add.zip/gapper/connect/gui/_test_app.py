from gapper.connect.gui.app_ui import GradescopeConnect

app = GradescopeConnect()
