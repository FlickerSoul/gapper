"""The problem extras module.

This module contains helpers and decorators for extra problem configuration.
"""
from .gradescope_connect import gs_connect

__all__ = ["gs_connect"]
