"""The CLI for the gapper (gap) package."""
from .cli import app

app()
