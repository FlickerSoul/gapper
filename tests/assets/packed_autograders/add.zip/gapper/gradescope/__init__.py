"""Gradescope Autograder Environment module."""
