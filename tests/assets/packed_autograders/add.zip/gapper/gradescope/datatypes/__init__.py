"""Gradescope Data Types module."""
