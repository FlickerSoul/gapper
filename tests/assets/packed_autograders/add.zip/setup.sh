#!/usr/bin/env bash

set -euo pipefail

# install python 3.12
add-apt-repository -y ppa:deadsnakes/ppa
apt-get update -y
apt-get install -y software-properties-common
apt-get install -y python3.12 python3.12-distutils
ln -s $(which python3.12) $(which python3)a

# install gapper
curl -sS https://bootstrap.pypa.io/get-pip.py | python3.12
pip install --upgrade setuptools wheel
pip install -e /autograder/source
python3.12 -m pip cache purge